def s3_thumbnail_generator(event, context):
    return "This was triggered by s3 bucket event!"