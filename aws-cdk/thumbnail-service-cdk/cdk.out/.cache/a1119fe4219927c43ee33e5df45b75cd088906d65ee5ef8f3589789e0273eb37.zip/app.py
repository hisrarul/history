def s3_thumbnail_generator(event, context):
    return ""